package com.example.teacherday

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Button
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var btnMyLessons: Button
    private lateinit var btnExit: Button
    private lateinit var tvOutput: TextView
    private lateinit var scrollView: ScrollView

    private val parser = ScheduleParser()

    private val requestStoragePermission = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        checkStoragePermissionAndParse()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnMyLessons = findViewById(R.id.btn_my_lessons)
        btnExit = findViewById(R.id.btn_exit)
        tvOutput = findViewById(R.id.tv_output)
        scrollView = findViewById(R.id.scroll_view)

        btnMyLessons.setOnClickListener {
            checkStoragePermissionAndParse()
        }

        btnExit.setOnClickListener {
            finishAffinity()
        }
    }

    private fun checkStoragePermissionAndParse() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (Environment.isExternalStorageManager()) {
                parseLatestSchedule()
            } else {
                requestManageStoragePermission()
            }
        } else {
            requestLegacyStoragePermission()
        }
    }

    private fun requestManageStoragePermission() {
        AlertDialog.Builder(this)
            .setTitle("Разрешение")
            .setMessage("Приложению нужен доступ к папке Загрузки/MAX. Нажмите «Разрешить» и в открывшемся окне выберите наше приложение.")
            .setPositiveButton("Разрешить") { _, _ ->
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                }
                requestStoragePermission.launch(intent)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun requestLegacyStoragePermission() {
        if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            parseLatestSchedule()
        } else {
            requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), 100)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100 && grantResults.isNotEmpty() &&
            grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            parseLatestSchedule()
        } else {
            showError("Нет разрешения на чтение файлов")
        }
    }

    private fun parseLatestSchedule() {
        tvOutput.text = "Загрузка расписания..."
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    parser.parseLatest()
                } catch (e: Exception) {
                    Result.Error(e.message ?: "Неизвестная ошибка")
                }
            }
            withContext(Dispatchers.Main) {
                when (result) {
                    is Result.Success -> displayLessons(result.lessons)
                    is Result.Error -> showError(result.message)
                }
            }
        }
    }

    private fun displayLessons(lessons: List<Lesson>) {
        if (lessons.isEmpty()) {
            tvOutput.text = "Уроков на сегодня не найдено."
            return
        }

        // Группируем по номеру урока
        val groupedByLesson = lessons.groupBy { it.lessonNumber }
        val maxLesson = lessons.maxOfOrNull { it.lessonNumber } ?: 1

        val sb = StringBuilder()
        for (lessonNum in 1..maxLesson) {
            val lessonsForNum = groupedByLesson[lessonNum]
            if (lessonsForNum != null && lessonsForNum.isNotEmpty()) {
                // Сортируем по классу
                val sortedByClass = lessonsForNum.sortedBy { it.className }
                // Формируем строку вида: "5а Труд/6б Труд"
                val classesSubjects = sortedByClass.joinToString("/") { "${it.className} ${it.subject}" }
                sb.append("$lessonNum - $classesSubjects\n")
            } else {
                sb.append("$lessonNum - Окно\n")
            }
        }

        tvOutput.text = sb.toString()
        scrollView.post { scrollView.fullScroll(ScrollView.FOCUS_UP) }
    }

    private fun showError(message: String) {
        tvOutput.text = "Ошибка: $message"
    }
}

sealed class Result {
    data class Success(val lessons: List<Lesson>) : Result()
    data class Error(val message: String) : Result()
}